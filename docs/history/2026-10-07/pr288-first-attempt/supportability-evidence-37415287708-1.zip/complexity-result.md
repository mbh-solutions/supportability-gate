# Supportability Complexity Result

- Overall result: `BLOCK`
- Repository: `github.com/mbh-solutions/supportability-gate`
- Base: `73b9a98412d323b958d9df67932c3bf1ae666209`
- Head: `dc80e892d7e504726cdf6def77e245b70fd917c4`

| Function | Start | End | Gap | Next target | Decision |
|---|---:|---:|---:|---:|---|
| _blob_batches | — | 4 | — | — | PASS |
| _materialization_entries | — | 6 | — | — | PASS |
| _materialization_path | — | 2 | — | — | PASS |
| _read_batch_blob | — | 3 | — | — | PASS |
| _validate_blob_content | — | 2 | — | — | PASS |
| read_regular_blobs | — | 4 | — | — | PASS |
| run_git | 5 | 5 | — | — | PASS |
| sandbox_command | 8 | 9 | — | — | PASS |

## Policy blocks

- `QUALITY_GATE_FAILED:python.pytest.v1`

## Structured review evidence

```json
{
  "architecture": {
    "dependency_direction": "Preserved: profile construction and immutable Git access remain in existing source modules; target execution and its worker guard remain in the trusted hosted collector. Diagnostics never feed policy decisions. Exact runtime pins permit protected bootstrap without target-controlled plugin loading.",
    "reviewed_paths": [
      ".github/workflows/organization-required.yml",
      ".supportability-review.toml",
      "docs/product/Evidence-Model.md",
      "pyproject.toml",
      "requirements-dev.lock",
      "src/supportability_gate/git_changes.py",
      "src/supportability_gate/quality_profile.py",
      "src/supportability_gate/quality_runner.py",
      "tests/hosted_characterization.py",
      "tests/hosted_quality_profile.py",
      "tests/quality_pytest_entry.py",
      "tests/quality_pytest_guard.py",
      "tests/test_characterization_capture_timing.py",
      "tests/test_quality_capture_timing.py",
      "tests/test_quality_materialization.py",
      "tests/test_quality_profile.py",
      "tests/test_quality_pytest_guard.py"
    ]
  },
  "behavior": {
    "intended_behavior": "Reduce fixed-profile overhead with bounded immutable Git batches and two isolated pytest workers, preserving complete test execution, branch coverage, fixed resource/time limits and all eight policy outcomes. Retain operational timings separately from authoritative evidence.",
    "proof": "Focused batch/path/mode/isolation and timing controls pass. A six-case Linux comparison preserves all collected cases, 2316 covered lines and 661 branch directions while reducing 37.268 seconds to 23.588 seconds. Missing completion/coverage controls block, and a hostile helper-name fixture proves absolute trusted worker bootstrap."
  },
  "characterization": {
    "captured_behavior": "The complete test collection and merged source coverage are preserved while execution scheduling and immutable source-copy transport change. Existing source-bound characterization goldens, fixed timeouts, resource limits and policy contexts remain unchanged.",
    "proof": "Exact Git-byte inventories match old and new copies. The finite serial/two-worker witness retains six completed tests and identical line/branch coverage; two-worker completion guards reject missing workers, acknowledgements, phases and coverage suppression."
  },
  "human_review": {
    "cohesion": "Existing Git and profile modules retain transport/construction. Trusted collector entry and guard own worker startup and completeness. No product or consumer business logic changes.",
    "intended_behavior": "Preserve every test and coverage requirement, fixed resource/time limits and all eight contexts while parallelizing only fixed Python test execution and reducing source preparation overhead.",
    "naming": "Immutable blob batches, isolated worker bootstrap, completion receipts and phase timings name their specific responsibilities.",
    "reviewability": "One consolidated generic runner change with bounded old/new setup measurements, finite serial/parallel coverage comparison and focused negative controls. Local measurements do not claim an end-to-end hosted speedup."
  },
  "incremental_refactor": {
    "completed_step": "Bounded immutable source materialization, independent build copy, fixed isolated two-worker pytest with complete coverage/worker guards, retained phase timings, and capture-outcome wiring.",
    "target": "Reduce measured quality execution/setup overhead and expose remaining hosted stage costs without narrowing checks."
  },
  "module_boundaries": [],
  "responsibility_boundary": {
    "does_not_own": "Target code execution, quality policy, artifact publication, semantic truth or owner authorization.",
    "owns": "Fixed no-shell Git access and exact immutable repository, tree, blob and diff identities.",
    "path": "src/supportability_gate/git_changes.py"
  },
  "schema_version": "1.0",
  "separation_of_concerns": {
    "after": "Immutable batch transport stays in git_changes; fixed profile construction stays in quality_profile/quality_runner; read-only collector helpers own isolated worker startup and completion; non-authoritative diagnostics expose capture/quality timings; workflow outputs preserve actual capture status.",
    "before": "The hosted runner repeated per-file Git startup, executed independent tests serially, and retained no successful phase/adapter timing. Capture job outcomes were not exported to their downstream consumers.",
    "boundaries": [
      {
        "after": "Group at most eight mebibytes of file contents per batch and handle oversized files alone at the prior one-file memory scale.",
        "before": "Source preparation invoked Git for every individual file.",
        "kind": "function",
        "path": "src/supportability_gate/git_changes.py",
        "symbol": "_blob_batches"
      },
      {
        "after": "List validated regular paths, modes, object identities and byte sizes before forming bounded batches.",
        "before": "File sizes were not needed because every blob used separate Git processes.",
        "kind": "function",
        "path": "src/supportability_gate/git_changes.py",
        "symbol": "_materialization_entries"
      },
      {
        "after": "Reject absolute, noncanonical, traversal, metadata, and cross-platform separator paths before any materialized writes.",
        "before": "Materialization assumed the literal Git file path could be joined to its output root.",
        "kind": "function",
        "path": "src/supportability_gate/git_changes.py",
        "symbol": "_materialization_path"
      },
      {
        "after": "Validate batch object ID, type, bounded length, binary delimiter, and recomputed Git object hash for each listed tree entry.",
        "before": "Individual cat-file invocations provided the contents of each independently listed path.",
        "kind": "function",
        "path": "src/supportability_gate/git_changes.py",
        "symbol": "_read_batch_blob"
      },
      {
        "after": "Verify exact size and Git object hash incrementally without duplicating the file buffer for hashing.",
        "before": "Individual Git reads supplied file bytes without a separate materializer hash check.",
        "kind": "function",
        "path": "src/supportability_gate/git_changes.py",
        "symbol": "_validate_blob_content"
      },
      {
        "after": "Yield validated regular-file contents using one sized listing and bounded batch object processes; retain at most one batch or one oversized individual file.",
        "before": "One tree listing plus two Git processes per file were needed for each source copy.",
        "kind": "function",
        "path": "src/supportability_gate/git_changes.py",
        "symbol": "read_regular_blobs"
      },
      {
        "after": "The same finite no-shell invocation boundary also accepts explicit trusted batch object IDs on standard input.",
        "before": "Fixed Git invocation captured output without supplying batch input.",
        "kind": "function",
        "path": "src/supportability_gate/git_changes.py",
        "symbol": "run_git"
      },
      {
        "after": "Declare the fixed byte/file bounds and imports used by validated immutable batch transport.",
        "before": "Materialization had no bounded batch transport configuration.",
        "kind": "module",
        "path": "src/supportability_gate/git_changes.py",
        "symbol": "src/supportability_gate/git_changes.py"
      },
      {
        "after": "Run the same complete suite using a fixed read-only bootstrap and two isolated workers, merged branch coverage, and fail-closed completion guards.",
        "before": "The Python test adapter ran the complete suite serially under coverage run.",
        "kind": "module",
        "path": "src/supportability_gate/quality_profile.py",
        "symbol": "src/supportability_gate/quality_profile.py"
      },
      {
        "after": "Disable plugin autoload and bind the fixed coverage database path inside the existing immutable no-network resource boundary.",
        "before": "Python test execution inherited no explicit fixed worker plugin-autoload and coverage-file environment.",
        "kind": "function",
        "path": "src/supportability_gate/quality_runner.py",
        "symbol": "sandbox_command"
      }
    ]
  }
}
```

Derived from `complexity-result.json`.
