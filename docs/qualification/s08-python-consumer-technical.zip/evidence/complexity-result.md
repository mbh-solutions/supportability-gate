# Supportability Complexity Result

- Overall result: `TECHNICAL_FAILURE`
- Repository: `github.com/mbh-solutions/twmn`
- Base: `671f5c2f570882f09e30c9e632cb1566ca66fe41`
- Head: `009d922caaf67ac37a291ba61a5deb30e05826a5`

| Function | Start | End | Gap | Next target | Decision |
|---|---:|---:|---:|---:|---|

## Technical errors

- `MISSING_QUALITY_EVIDENCE`: [Errno 2] No such file or directory: '/home/runner/work/_temp/quality/quality-gates.json'

## Policy blocks

- `INSUFFICIENT_REVIEW_EVIDENCE:separation_of_concerns.boundaries`

## Structured review evidence

```json
{
  "architecture": {
    "dependency_direction": "Study depends on source and notebook layers; resource composition depends on file parsing. Publication, ingestion and research do not depend on resource study. No new package dependency.",
    "reviewed_paths": [
      "src/twmn_corpus/lesson_resource_files.py",
      "src/twmn_corpus/lesson_resources.py",
      "src/twmn_corpus/lesson_sources.py",
      "src/twmn_corpus/lesson_study.py",
      "skills/twmn/scripts/invoke-research.ps1",
      "skills/twmn/scripts/resource-study-validation.ps1"
    ]
  },
  "behavior": {
    "intended_behavior": "Support validated resource-only lesson study with original description, ZIP member and PDF page units, preserving transcript behavior and separate exercise assessment.",
    "proof": "56 focused pytest cases pass; synthetic resource tests cover every page, restart and receipt replay, changed/missing bytes, duplicate identity, wrong ownership, and unsafe ZIP paths. Installed launcher tests exercise both schemas and reject malformed resource packets."
  },
  "characterization": {
    "captured_behavior": "The existing contiguous notebook and transcript tests pass unchanged; resources reuse atomic receipts without pretending to be transcripts.",
    "proof": "tests/test_lesson_resources.py, test_lesson_sources.py, test_lesson_study.py and test_lesson_notebook.py; existing lesson-study-boundary characterization preserved."
  },
  "human_review": {
    "cohesion": "Parsing, source composition, checkpoint persistence and launcher validation remain separate responsibilities.",
    "intended_behavior": "A complete read receipt does not imply visual or exercise mastery; original source changes block acknowledgements.",
    "naming": "Resource units and PDF pages are named distinctly from transcripts; legacy cursor storage fields are explicitly documented.",
    "reviewability": "Only synthetic test materials and implementation metadata are committed. The exact private L048 files stay outside Git."
  },
  "incremental_refactor": {
    "completed_step": "Added a resource-specific schema and narrow file parsers; retained transcript schema, validation and notebook semantics.",
    "target": "Recover the exact L048 resource-page workflow using existing notebook and Publisher distribution."
  },
  "module_boundaries": [
    {
      "basis": "responsibility",
      "justification": "Inert resource byte validation and parsing are separate from publication/source-map resolution.",
      "owner_path": "src/twmn_corpus/lesson_sources.py",
      "path": "src/twmn_corpus/lesson_resource_files.py"
    },
    {
      "basis": "responsibility",
      "justification": "Resource-unit composition and visual coverage belong to lesson source reading, separate from binary parsing and transcript validation.",
      "owner_path": "src/twmn_corpus/lesson_sources.py",
      "path": "src/twmn_corpus/lesson_resources.py"
    }
  ],
  "responsibility_boundary": {
    "does_not_own": "Network acquisition, corpus ingestion, workspace installation/execution, rendering fidelity, exercise correctness or trading.",
    "owns": "Original resource identity, creator-order unit composition and separate visual-attestation coverage.",
    "path": "src/twmn_corpus/lesson_resources.py"
  },
  "schema_version": "1.0",
  "separation_of_concerns": {
    "after": "lesson_resource_files validates and statically parses originals; lesson_resources owns ordered resource units and distinct visual coverage; lesson_sources retains publication validation; lesson_study retains notebook orchestration; the installed bridge validates the resource envelope.",
    "before": "The S01 source resolver only accepted transcript media, blocking a correctly classified resource-page lesson."
  }
}
```

Derived from `complexity-result.json`.
