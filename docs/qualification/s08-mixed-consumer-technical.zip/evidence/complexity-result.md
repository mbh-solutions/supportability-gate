# Supportability Complexity Result

- Overall result: `TECHNICAL_FAILURE`
- Repository: `github.com/mbh-solutions/twmn-portfolio`
- Base: `70c9f5eab270992242d609757104543726aa53b5`
- Head: `9c2b6f7e11cf173daa1ef9d902264c9dc103446f`

| Function | Start | End | Gap | Next target | Decision |
|---|---:|---:|---:|---:|---|

## Technical errors

- `MISSING_QUALITY_EVIDENCE`: [Errno 2] No such file or directory: '/home/runner/work/_temp/quality/quality-gates.json'

## Policy blocks

- `INSUFFICIENT_REVIEW_EVIDENCE:separation_of_concerns.boundaries`

## Structured review evidence

```json
{
  "architecture": {
    "dependency_direction": "The accepted S04 execution specification (hash-bound in ctv_rule_table and the S06/S07 evidence) remains the authority. The dependency direction stays one-way: rule_table <- frame <- rule_engine <- order_owner <- broker_adapter, now integrated by the S07 runtime layer — the trade register and operations log are standalone durable stores; runtime_status and scan_incidents read the journal, operations log, receipts and register; the tracker bridge reads the journal and register and writes only through the tracker's own ctv_store/ctv_repository/ctv_commands APIs against an isolated copy, reusing the tracker's exact ctv_accounting_inputs normalization. The owner consumes pause state through the injected fail-closed pause_source callable and never reads the runtime layer; the bridge references the alert-ledger module only to refuse its canonical database as a bridge target; no module imports the collector or any provider client, and no live REST transport exists in this delivery.",
    "reviewed_paths": [
      "src/twmn_portfolio/ctv_trade_register.py",
      "src/twmn_portfolio/ctv_incidents.py",
      "src/twmn_portfolio/ctv_runtime.py",
      "src/twmn_portfolio/ctv_tracker_bridge.py",
      "src/twmn_portfolio/ctv_order_journal.py",
      "src/twmn_portfolio/ctv_order_owner.py",
      "tests/ctv_runtime/",
      "tests/ctv_rules/test_journal_ledger_isolation.py",
      "tests/characterization/ctv-rule-engine-v3.characterization.py",
      "tests/characterization/ctv-runtime-integration-v1.characterization.py",
      ".supportability-characterization.json",
      "docs/ctv-mastery/s07/",
      "docs/ctv-mastery/README.md",
      ".supportability-review.toml"
    ]
  },
  "behavior": {
    "intended_behavior": "Integrate durable lifecycle accounting, operational visibility and safe recovery with the existing tracker, keeping live execution disabled and the canonical ledger untouched: register one durable trade identity per checklist/decision (ctv_trade_register), record incidents, notifications and the owner's entry pause in a fail-closed operations log (ctv_incidents), assemble runtime status from durable state only and triage uncertain responses, receipt incidents and trailing reconciliation requirements while resolving recovered incidents (ctv_runtime), and project journal facts into an isolated tracker copy exclusively through the tracker's own storage API with deterministic ctv7-<digest> command ids so replays return stored receipts instead of duplicating accounting (ctv_tracker_bridge). The owner gains the spec 6.5 entry-pause guard (management events continue), partial-leg-fill obligations in reconcile receipts and ack-aware containment-expiry cancels; the journal treats a complete fill as terminal. Completion requires known costs on every projected cash event; unknown costs report COMPLETION_PENDING, and session-level risk_costs events are reported unprojected, never attributed. The live frame-producer loop and the live runtime loop are not built and remain S08.",
    "proof": "Entry gate verified live before mutation: board #57 read Done / Proven / On scope; #58 was the only Ready item with none In Progress; base main = 4abec888d43c99b652707be9fbb69c09cd5b4af4 with zero open PRs at dispatch; predecessor bindings re-derived with zero hash mismatches (execution-spec.md d8dbe15f..., acceptance-cases.json 1dcecdda...). Mandatory disclosure executed (ask_tradestation then get_trading_environment, 2026-09-21): environment sim, unchanged; no supported account operation was performed. Isolated worktree codex-ctv-s07 created from main; the main checkout untouched. Verification on the exact working tree: python -m pytest -q = 886 passed + 62 subtests (base collection gathers 845 + 62; the S07 delta of 41 is the 40 tests in tests/ctv_runtime/ plus the extended isolation tests); ruff check --select E4,E7,E9,F,I,UP --line-length 100 = passed on src and tests; ruff format --check at line length 100 = passed; ruff C901 max-complexity 10 = passed on production sources; mypy --strict src = no issues in 73 files; the import-boundary receipt docs/evidence/ctv-tracker-s07-quality.json records the import-linter run (adapter python.import-linter.v1, acyclic contract, exit 0) captured against a pinned source inventory with its temporary contract configuration intentionally not committed, and the in-tree isolation suite pins the module boundaries it attests. Independent adversarial review (two reviewer contexts, triangulated; verdict 0 CRITICAL / 1 MAJOR / 5 MINOR / 2 NOTE) required and received fixes now in this delivery: bridge base_revision values are live reads with completion-state twin-matching so a crash mid-projection resumes instead of permanent REVISION_CONFLICT (tested), uncertain-response resolution requires a later clean receipt (tested), and operations-log dedupe repairs a notification lost to a crash between the two appends without re-notifying (tested). The ctv-rule-engine-v3 characterization driver executed against the base target 4abec88 (temporary detached worktree, removed after the run) and the head target with exit 0 and byte-identical stdout; the captured behavior matches the golden exactly. The ctv-runtime-integration-v1 characterization driver executed against the base target (the four runtime modules are absent there, so the exercising block is skipped) and the head target with exit 0 and byte-identical stdout; the captured behavior matches the golden exactly, and repeated head runs are byte-identical. Canonical-ledger preservation is tested: the bridge refuses the canonical tracker database and any alerts-directory sibling (CANONICAL_LEDGER_PROTECTED), no runtime module references the alerts database path, and the isolation suite walks every S07 runtime module for ledger and LOCALAPPDATA references. No order placed, cancelled or replaced; no trading-environment change; the delivered owner still refuses every broker write with ORDERS_DISABLED."
  },
  "characterization": {
    "captured_behavior": "This delivery (base 4abec888d43c99b652707be9fbb69c09cd5b4af4) changes exactly 23 tracked files (25 diff paths counting both sides of the two recorded renames): four new production modules under src/twmn_portfolio/ (ctv_incidents.py, ctv_runtime.py, ctv_tracker_bridge.py, ctv_trade_register.py); two modified production modules (ctv_order_journal.py open_intents terminal-fill rule; ctv_order_owner.py pause guard, partial-leg-fill obligations, acknowledged-order expiry cancels, takeover pause wiring); the new tests/ctv_runtime/ directory (runtime_helpers.py plus five test files); the extended tests/ctv_rules/test_journal_ledger_isolation.py; the characterization scenario replacement (ctv-rule-engine-v2.characterization.py renamed to ctv-rule-engine-v3 with only the SCENARIO string changed, the golden byte-identical under the v3 name); the swapped .supportability-characterization.json entry covering the same six paths plus the new ctv-runtime-integration-v1 entry covering the four new runtime modules, with its driver tests/characterization/ctv-runtime-integration-v1.characterization.py and its golden; the new docs/ctv-mastery/s07/ evidence directory including the delivery manifest; the docs/ctv-mastery/README.md delivery-state text and artifact-index entry; and this review file. No other tracked file changed.",
    "proof": "git diff --name-status 4abec888d43c99b652707be9fbb69c09cd5b4af4 HEAD contains exactly 23 rows: the 23 tracked files above, with git recording the v3 driver as an R099 rename and the v3 golden as an R100 rename (25 unique paths counting both rename sides). Nothing under src/web/, tests/web/, docs/ctv-mastery/ preceding S07, the notebooks or any ledger, tracker or provider path changed. The pre-existing module_boundaries entries in this file are preserved byte-for-byte; four entries are appended for the new modules. The v3 driver (PYTHONPATH set to the target's src) executed against the base target in a temporary detached worktree at 4abec88 and against the head target: exit 0, byte-identical stdout on both sides, and the behavior field matching the golden. The ctv-runtime-integration-v1 driver ran the same way on both targets: exit 0, byte-identical stdout on both sides (the exercising block is skipped at the base because the four modules are absent there), the behavior field matching the golden, and repeated head runs byte-identical. separation_of_concerns.boundaries below is exactly the gate's own derivation for this diff, produced by executing the gate's git_changes, contract, classification and responsibility-span code against base and head (78 identities); every entry for unchanged modules and for functions untouched by the diff is absent."
  },
  "human_review": {
    "cohesion": "The S07 delivery from base 4abec88 changes exactly the 23 tracked files recorded in characterization.captured_behavior: four new runtime modules, two focused owner and journal additions, the new tests/ctv_runtime/ suite, the extended isolation tests, the v3 characterization scenario with a byte-identical golden and the new ctv-runtime-integration-v1 scenario with its driver and golden, the characterization manifest entries, the S07 evidence directory, the README delivery-state text and this review manifest; no notebook, ledger, tracker, provider or unrelated evidence changed.",
    "intended_behavior": "Integrate journal, monitoring and recovery with live execution disabled; merge on green required checks with zero unresolved threads; S08 stays Backlog and is not started.",
    "naming": "Reading coverage, connection qualification, producer qualification, decision fidelity, runtime integration, operational practice and trading performance are separate verdicts.",
    "reviewability": "Runtime integration demonstrated by 37 new offline deterministic tests plus the extended isolation suite; artifact hashes at the delivered head recorded in docs/ctv-mastery/s07/manifest.json; the independent adversarial review with findings and resolutions recorded in docs/ctv-mastery/s07/s07-independent-review.md; the boundaries exactly the gate's own derivation (77 identities); no account identifier, token or secret appears anywhere."
  },
  "incremental_refactor": {
    "completed_step": "Verified the entry gate live and created the isolated worktree from main 4abec88 after re-deriving the predecessor binding hashes with zero mismatches; disclosed the sim environment through the mandatory gate without performing any account operation; implemented the durable trade register binding checklist/decision ids to runtime trades with rebind refusal; implemented the fsynced operations log with deduplicated incidents, durable resolutions, notification records, pause records and fail-closed construction on corrupt or gapped logs; assembled runtime status from durable state only and implemented the incident scan with receipt supersession and recovery resolution; implemented the tracker bridge writing only through the tracker's own storage API on isolated copies with deterministic ctv7-<digest> command ids, receipt replay, COMMAND_CONFLICT incidents, the canonical-ledger guard, reconcile and obligations gates, known-cost completion and unprojected risk_costs reporting; added the owner's spec 6.5 pause guard (fail-closed, management continuing), partial-leg-fill obligation reporting in reconcile receipts and ack-aware containment-expiry cancels; made open_intents treat a complete fill as terminal; kept the broker-write adapters disabled with no live transport; and extended the characterization with the revision-stable v3 scenario plus the new ctv-runtime-integration-v1 scenario covering the four new runtime modules, both verified byte-identical against base and head. No order placed, cancelled or replaced; environment unchanged; no indicator, ledger, provider or ingestion path touched.",
    "target": "Integrate durable lifecycle accounting, operational visibility and safe recovery with the existing tracker, keep live execution disabled, keep the canonical ledger and installed tracker untouched by trading code, then stop at the S07 boundary with S08 untouched and Backlog."
  },
  "module_boundaries": [
    {
      "basis": "responsibility",
      "justification": "Dedicated shadow-interpretation responsibility depends inward on immutable ledger evidence and exposes no tracker or execution path.",
      "owner_path": "src/twmn_portfolio/shadow_parser.py",
      "path": "src/twmn_portfolio/shadow_parser.py"
    },
    {
      "basis": "responsibility",
      "justification": "Dedicated tracker responsibility appends owner-period records and reduces linked views from immutable ledger evidence without collector, broker, or order paths.",
      "owner_path": "src/twmn_portfolio/tracker.py",
      "path": "src/twmn_portfolio/tracker.py"
    },
    {
      "basis": "responsibility",
      "justification": "Owns bounded native snapshot inspection only, using stdlib with no ledger, tracker, broker or execution dependency. Positional plot evidence remains separate from strategy interpretation.",
      "owner_path": "src/twmn_portfolio/ctv_native_export.py",
      "path": "src/twmn_portfolio/ctv_native_export.py"
    },
    {
      "basis": "responsibility",
      "justification": "Retain a source-bound persistent receipt for every verified snapshot and create the snapshot destination exclusively, rejecting redirected storage paths; preserve backup-first daily/import/migration semantics and original snapshot bytes.",
      "owner_path": "src/twmn_portfolio/ctv_backup.py",
      "path": "src/twmn_portfolio/ctv_backup.py"
    },
    {
      "basis": "responsibility",
      "justification": "Preserve original entry and image/draft transactions while capturing an immutable pre-event account/configuration denominator and cost assumption snapshot.",
      "owner_path": "src/twmn_portfolio/ctv_commands.py",
      "path": "src/twmn_portfolio/ctv_commands.py"
    },
    {
      "basis": "responsibility",
      "justification": "Require imported provenance to match a unique historical event, invoke reconstructed import-row/period/batch verification in the same full verifier, and retain ordinary lifecycle and legacy integrity boundaries.",
      "owner_path": "src/twmn_portfolio/ctv_integrity.py",
      "path": "src/twmn_portfolio/ctv_integrity.py"
    },
    {
      "basis": "responsibility",
      "justification": "Versioned additive SQL objects, immutable trigger declarations and extension identity; this module opens no database connection.",
      "owner_path": "src/twmn_portfolio/ctv_manifest.py",
      "path": "src/twmn_portfolio/ctv_manifest.py"
    },
    {
      "basis": "responsibility",
      "justification": "Read each immutable trade identity definition when appending events or saving working state, and allow an explicit import source version while retaining ordinary owner defaults and existing event hashes/receipts.",
      "owner_path": "src/twmn_portfolio/ctv_repository.py",
      "path": "src/twmn_portfolio/ctv_repository.py"
    },
    {
      "basis": "responsibility",
      "justification": "Explicit synthetic initialization and backup-first transactional extension migration with legacy fingerprint preservation.",
      "owner_path": "src/twmn_portfolio/ctv_schema.py",
      "path": "src/twmn_portfolio/ctv_schema.py"
    },
    {
      "basis": "responsibility",
      "justification": "Admit only bounded recovery operation fields, retain pure validation/calculation outside the storage exception boundary, and route validated storage operations through one helper preserving cache invalidation, command/revision/receipt and typed error semantics.",
      "owner_path": "src/twmn_portfolio/ctv_store.py",
      "path": "src/twmn_portfolio/ctv_store.py"
    },
    {
      "basis": "responsibility",
      "justification": "Safe boundary errors, finite deterministic JSON serialization, SHA-256 identities and canonical UTC recording times.",
      "owner_path": "src/twmn_portfolio/ctv_types.py",
      "path": "src/twmn_portfolio/ctv_types.py"
    },
    {
      "basis": "responsibility",
      "justification": "Bounded draft fields, explicit occurrence precision, Central date and DST validation, source URLs and image metadata.",
      "owner_path": "src/twmn_portfolio/ctv_validation.py",
      "path": "src/twmn_portfolio/ctv_validation.py"
    },
    {
      "basis": "responsibility",
      "justification": "Extend the finite worker vocabulary for backup list/comparison/open/read/close export operations while preserving private-pipe framing, response identity and safe error handling.",
      "owner_path": "src/twmn_portfolio/ctv_worker.py",
      "path": "src/twmn_portfolio/ctv_worker.py"
    },
    {
      "basis": "responsibility",
      "justification": "Exact additive schema registration shared with legacy ledger validators; only the complete recognized manifest is accepted.",
      "owner_path": "src/twmn_portfolio/schema_registry.py",
      "path": "src/twmn_portfolio/schema_registry.py"
    },
    {
      "basis": "responsibility",
      "justification": "Bounded image signature, dimension and decoder verification, plus readback validation of original image bytes.",
      "owner_path": "src/web/attachments.ts",
      "path": "src/web/attachments.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Expose bounded typed backup list/comparison/export preparation/status and escaped generated download URLs through existing same-origin session/CSRF/no-store controls; grant full-verification timeout to export preparation without changing mutation identity rules.",
      "owner_path": "src/web/client-api.ts",
      "path": "src/web/client-api.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Compose the focused reusable backup panel alongside retained account/import settings, delegating backup selection/review/download presentation while preserving existing navigation and trade autosave responsibilities.",
      "owner_path": "src/web/client-app.ts",
      "path": "src/web/client-app.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Draft save coordination, pending and acknowledged revisions, uncertain retry identity, definitive rejection correction and conflict resolution.",
      "owner_path": "src/web/client-save.ts",
      "path": "src/web/client-save.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Typed DOM construction and readable draft/status/history components that render owner text as text and preserve entered values.",
      "owner_path": "src/web/client-view.ts",
      "path": "src/web/client-view.ts"
    },
    {
      "basis": "responsibility",
      "justification": "The browser mount entry point; application startup occurs only when the known root element exists.",
      "owner_path": "src/web/client.ts",
      "path": "src/web/client.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Accept cancellation during startup, close only owned worker/server resources, bind and remove inherited desktop controls, and emit a private READY line only after successful local launch; retain explicit loopback assets/runtime verification.",
      "owner_path": "src/web/launch.ts",
      "path": "src/web/launch.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Loopback Host and Origin checks, private session cookies, CSRF validation and restrictive response security headers.",
      "owner_path": "src/web/security.ts",
      "path": "src/web/security.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Permit an explicit zero revision only when the account route opts in, supporting existing accounts with no versioned account event yet; default trade mutation revisions remain positive and command identity remains mandatory.",
      "owner_path": "src/web/server-validation.ts",
      "path": "src/web/server-validation.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Compose the focused backup route module through the unchanged private security/application boundary and remove its duplicate inline backup registration; preserve all existing actual trade/account/import/report routes.",
      "owner_path": "src/web/server.ts",
      "path": "src/web/server.ts"
    },
    {
      "basis": "responsibility",
      "justification": "The fixed minimal HTML document referencing only first-party compiled browser modules and styles.",
      "owner_path": "src/web/shell.ts",
      "path": "src/web/shell.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Add only the matching catalog/comparison/export-session operation names; retain framing and safe result/error types rather than introducing paths, executable commands or arbitrary SQL.",
      "owner_path": "src/web/worker-protocol.ts",
      "path": "src/web/worker-protocol.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Apply the same bounded verification allowance to backup listing, comparison and export opening; chunk reads/close retain the normal bounded request timeout and all existing process/response controls.",
      "owner_path": "src/web/worker.ts",
      "path": "src/web/worker.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Explicit original debit contract, whole quantity, decimal price/cost and Central-time validation; keep owner-observed setup and intended fly separate from actual legs.",
      "owner_path": "src/twmn_portfolio/ctv_entry.py",
      "path": "src/twmn_portfolio/ctv_entry.py"
    },
    {
      "basis": "responsibility",
      "justification": "Bounded revised-v4 setup fields and four-state checklist normalization; retain unfinished numeric strings as draft evidence and report field gaps.",
      "owner_path": "src/twmn_portfolio/ctv_setup.py",
      "path": "src/twmn_portfolio/ctv_setup.py"
    },
    {
      "basis": "responsibility",
      "justification": "Original image select/paste preview, truthful pending/saved presentation, caption/observation metadata and retry-safe uploads coordinated with acknowledged draft revisions.",
      "owner_path": "src/web/client-attachments.ts",
      "path": "src/web/client-attachments.ts"
    },
    {
      "basis": "responsibility",
      "justification": "The accepted immutable revised-v4 checklist labels, ordering, response vocabulary and thirteen TOD observations for typed browser rendering.",
      "owner_path": "src/web/client-checklist-definition.ts",
      "path": "src/web/client-checklist-definition.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Versioned checklist and exclusive TOD controls; independently represent checked, unchecked, unknown and not-applicable owner observations.",
      "owner_path": "src/web/client-checklist.ts",
      "path": "src/web/client-checklist.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Accessible typed DOM controls with explicit labels and associated help text; construct owner content as text.",
      "owner_path": "src/web/client-controls.ts",
      "path": "src/web/client-controls.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Display owner-local account names and Central period-opening times while retaining the exact stored account/period IDs and separate SIM/LIVE binding values.",
      "owner_path": "src/web/client-entry-fields.ts",
      "path": "src/web/client-entry-fields.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Labeled original-position, contract, account/period, time and numeric form inputs with targeted validation feedback and draft-preserving updates.",
      "owner_path": "src/web/client-form-fields.ts",
      "path": "src/web/client-form-fields.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Pure setup-form defaults and draft field/numeric presentation; preserve each stored response and raw owner-entered value while filling only unanswered checklist defaults.",
      "owner_path": "src/web/client-form-model.ts",
      "path": "src/web/client-form-model.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Compose the accepted New Trade setup, original-position and comments sections, optional actual-entry acknowledgement, and readback of recorded opening identity.",
      "owner_path": "src/web/client-form.ts",
      "path": "src/web/client-form.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Narrow static JSON schemas for the complete bounded setup draft and explicit original-entry command at the HTTP boundary.",
      "owner_path": "src/web/server-setup.ts",
      "path": "src/web/server-setup.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Replay explicit actual opening and lifecycle events into precise money, quantity, remaining obligation and classification projections without storage or broker effects.",
      "owner_path": "src/twmn_portfolio/ctv_accounting.py",
      "path": "src/twmn_portfolio/ctv_accounting.py"
    },
    {
      "basis": "responsibility",
      "justification": "Apply explicit openings, sales, conversions, component/leg closes and confirmed settlement to component inventory and recorded cashflows.",
      "owner_path": "src/twmn_portfolio/ctv_accounting_actions.py",
      "path": "src/twmn_portfolio/ctv_accounting_actions.py"
    },
    {
      "basis": "responsibility",
      "justification": "Normalize finite decimal, contract, cost, allocation, fill and settlement evidence without inferring missing money or quantities.",
      "owner_path": "src/twmn_portfolio/ctv_accounting_inputs.py",
      "path": "src/twmn_portfolio/ctv_accounting_inputs.py"
    },
    {
      "basis": "responsibility",
      "justification": "Maintain pure in-memory component splits, exact signed leg inventory and balanced-fly identity classification while preserving original lots.",
      "owner_path": "src/twmn_portfolio/ctv_accounting_model.py",
      "path": "src/twmn_portfolio/ctv_accounting_model.py"
    },
    {
      "basis": "responsibility",
      "justification": "Reuse the shared pure weighted-price function without changing qualified lifecycle money, quantity, risk or partial-realization meanings.",
      "owner_path": "src/twmn_portfolio/ctv_accounting_projection.py",
      "path": "src/twmn_portfolio/ctv_accounting_projection.py"
    },
    {
      "basis": "responsibility",
      "justification": "Validate reasoned immutable corrections and recalculate downstream accounting while preserving superseded values and completion history.",
      "owner_path": "src/twmn_portfolio/ctv_amendments.py",
      "path": "src/twmn_portfolio/ctv_amendments.py"
    },
    {
      "basis": "responsibility",
      "justification": "Append draft archive/restore actions and later original-image caption, observation and removal annotations while preserving immutable image bytes and completed financial evidence.",
      "owner_path": "src/twmn_portfolio/ctv_annotations.py",
      "path": "src/twmn_portfolio/ctv_annotations.py"
    },
    {
      "basis": "responsibility",
      "justification": "Recognize the explicit historical-summary event and overlay its dedicated source-bound projection on detail output without fabricating actual openings, management fills or completed unit outcomes.",
      "owner_path": "src/twmn_portfolio/ctv_lifecycle.py",
      "path": "src/twmn_portfolio/ctv_lifecycle.py"
    },
    {
      "basis": "responsibility",
      "justification": "Preserve actual lifecycle recording while enforcing complete period intervals and capturing immutable account/configuration/cost snapshots for later management events.",
      "owner_path": "src/twmn_portfolio/ctv_lifecycle_commands.py",
      "path": "src/twmn_portfolio/ctv_lifecycle_commands.py"
    },
    {
      "basis": "responsibility",
      "justification": "Verify each immutable lifecycle cutoff, effective-event lineage and completion snapshot against deterministic accounting replay, preserving earlier financial versions.",
      "owner_path": "src/twmn_portfolio/ctv_lifecycle_integrity.py",
      "path": "src/twmn_portfolio/ctv_lifecycle_integrity.py"
    },
    {
      "basis": "responsibility",
      "justification": "Calculate terminal option payoff and remaining exposure for common contract identities, with explicit zero/negative denominator policy and unsupported-risk disclosure.",
      "owner_path": "src/twmn_portfolio/ctv_risk.py",
      "path": "src/twmn_portfolio/ctv_risk.py"
    },
    {
      "basis": "responsibility",
      "justification": "Maintain separately enabled in-memory corrected setup observations with accessible unique controls, leaving accounting and autosave unchanged until a reasoned amendment applies.",
      "owner_path": "src/web/client-correction-setup.ts",
      "path": "src/web/client-correction-setup.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Serialize actual lifecycle requests with acknowledged draft revisions, preserve exact uncertain command values for retries and release revision holds only after known results.",
      "owner_path": "src/web/client-lifecycle-command.ts",
      "path": "src/web/client-lifecycle-command.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Typed lifecycle command and projection contracts distinguish actual cashflow, residual obligations, confirmed settlement, explicit costs, original occurrence metadata and financial versus behavioral completion.",
      "owner_path": "src/web/client-lifecycle-types.ts",
      "path": "src/web/client-lifecycle-types.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Coordinate lifecycle command submission, retry identity and acknowledged revisions with draft/image saves and explicit completion or amendment actions.",
      "owner_path": "src/web/client-lifecycle.ts",
      "path": "src/web/client-lifecycle.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Labeled management fields and explicit owner-input conversion into lifecycle payloads; preserve blank versus zero, actual cash direction and original local occurrence/offset when amending evidence.",
      "owner_path": "src/web/client-management-fields.ts",
      "path": "src/web/client-management-fields.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Render explicit lot/component allocations and exact residual leg input rows while retaining entered contract identity and whole quantities.",
      "owner_path": "src/web/client-management-rows.ts",
      "path": "src/web/client-management-rows.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Display each retained completed-snapshot original image and its frozen caption alongside its existing original-image link, making revision evidence visible in history and printed detail.",
      "owner_path": "src/web/client-management-view.ts",
      "path": "src/web/client-management-view.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Bounded static HTTP schemas for actual lifecycle, completion, amendment and annotation commands behind existing private revision and command headers.",
      "owner_path": "src/web/server-lifecycle.ts",
      "path": "src/web/server-lifecycle.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Normalize explicit SIM/LIVE account-period inputs, effective setting values, signed transactions, Central occurrence times and amendment reasons without inventing balances, fees or owner limits.",
      "owner_path": "src/twmn_portfolio/ctv_account_inputs.py",
      "path": "src/twmn_portfolio/ctv_account_inputs.py"
    },
    {
      "basis": "responsibility",
      "justification": "Route only recognized imported account-event types to source-reconstructing import integrity after existing account/period linkage checks, preserving full validation for ordinary owner events.",
      "owner_path": "src/twmn_portfolio/ctv_account_integrity.py",
      "path": "src/twmn_portfolio/ctv_account_integrity.py"
    },
    {
      "basis": "responsibility",
      "justification": "Include explicitly imported summaries, date-only historical realizations and signed historical/excluded flows in the same account calculations; keep excluded strategy activity separate from CTV profit and retain missing component detail.",
      "owner_path": "src/twmn_portfolio/ctv_account_projection.py",
      "path": "src/twmn_portfolio/ctv_account_projection.py"
    },
    {
      "basis": "responsibility",
      "justification": "Include explicit historical transaction/excluded flows in effective account history and accept a caller-supplied import source version while retaining the owner-entered default and identical append-only event lineage.",
      "owner_path": "src/twmn_portfolio/ctv_account_repository.py",
      "path": "src/twmn_portfolio/ctv_account_repository.py"
    },
    {
      "basis": "responsibility",
      "justification": "Bind event-time account denominators, opening/configuration assumptions and cost comparisons to immutable account/trade revision cutoffs; verify them without rewriting earlier events.",
      "owner_path": "src/twmn_portfolio/ctv_account_snapshots.py",
      "path": "src/twmn_portfolio/ctv_account_snapshots.py"
    },
    {
      "basis": "responsibility",
      "justification": "Respect source-date precision when checking imported account history against an actual period cutoff; same-day ambiguous date evidence cannot establish a prior instant or silently satisfy flat-period chronology.",
      "owner_path": "src/twmn_portfolio/ctv_accounts.py",
      "path": "src/twmn_portfolio/ctv_accounts.py"
    },
    {
      "basis": "responsibility",
      "justification": "Validate hypothetical same-component weighted fills and exact-leg risk inputs; reuse qualified Decimal money/risk and shared weighted prices without database writes, financial events or broker effects.",
      "owner_path": "src/twmn_portfolio/ctv_calculators.py",
      "path": "src/twmn_portfolio/ctv_calculators.py"
    },
    {
      "basis": "responsibility",
      "justification": "Own the pure unrounded quantity-weighted price calculation shared by recorded-trade projections and hypothetical calculators.",
      "owner_path": "src/twmn_portfolio/ctv_prices.py",
      "path": "src/twmn_portfolio/ctv_prices.py"
    },
    {
      "basis": "responsibility",
      "justification": "Freeze account mutation payload, command identity and revision across uncertain retries; release the pending request only on a known result or definitive validation/conflict response.",
      "owner_path": "src/web/client-account-command.ts",
      "path": "src/web/client-account-command.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Present reasoned account setting/transaction amendment inputs tied to preserved target events and retain original transaction type without replacing history.",
      "owner_path": "src/web/client-account-corrections.ts",
      "path": "src/web/client-account-corrections.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Format exact service percentage results for readable account/calculator display while keeping missing availability distinct and leaving all financial arithmetic in the shared core.",
      "owner_path": "src/web/client-account-display.ts",
      "path": "src/web/client-account-display.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Provide accessible labeled account/calculator fields, exact Central-time controls and explicit form extraction/reset actions while preserving supplied text and legitimate zero.",
      "owner_path": "src/web/client-account-fields.ts",
      "path": "src/web/client-account-fields.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Map selected-period setting, transaction, correction and equity evidence to readable labels with amounts, occurrence times and preserved history relationships.",
      "owner_path": "src/web/client-account-history.ts",
      "path": "src/web/client-account-history.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Render selected SIM/LIVE period book value, realized results, transaction-free equity, allocation/risk, configuration gaps and history without treating missing results as zero or broker balances.",
      "owner_path": "src/web/client-account-view.ts",
      "path": "src/web/client-account-view.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Compose hypothetical fill/leg rows and explicit multiplier, cash direction, contract identity and cost assumptions; distinguish blank unknown inputs from confirmed zero.",
      "owner_path": "src/web/client-calculator-fields.ts",
      "path": "src/web/client-calculator-fields.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Render weighted and whole-position risk/payoff results, original basis, costs and unavailable/unbounded states with the shared calculation assumptions visible.",
      "owner_path": "src/web/client-calculator-view.ts",
      "path": "src/web/client-calculator-view.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Coordinate standalone hypothetical calculation forms, retain entered values through failures, invalidate stale results after edits and call the existing typed API without creating records.",
      "owner_path": "src/web/client-calculators.ts",
      "path": "src/web/client-calculators.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Coordinate account forms with pending requests, revision conflicts, explicit latest-account review, dirty-field preservation and protected exact retries.",
      "owner_path": "src/web/client-settings-command.ts",
      "path": "src/web/client-settings-command.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Build explicit local account/period opening, effective cost/owner-limit configuration and signed account transaction forms; never supply generic CTV limits or inferred balances.",
      "owner_path": "src/web/client-settings-forms.ts",
      "path": "src/web/client-settings-forms.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Compose the private import panel with shared account selection, mutual pending-operation locks, import dirty-work reminders and post-apply account/new-period refresh without discarding an uncertain import request.",
      "owner_path": "src/web/client-settings.ts",
      "path": "src/web/client-settings.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Define bounded private HTTP account/period, settings, signed transaction and amendment routes with typed bodies, command/revision preconditions and existing supervised-worker dispatch.",
      "owner_path": "src/web/server-accounts.ts",
      "path": "src/web/server-accounts.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Define bounded private hypothetical weighted-price and exact-leg risk routes, preserving the existing same-origin security boundary while dispatching calculations without mutation receipts.",
      "owner_path": "src/web/server-calculators.ts",
      "path": "src/web/server-calculators.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Coordinate one verified canonical snapshot, shared validated filters, bounded deterministic history pages, statistics and exact numerator/denominator membership drilldown with version and cutoff metadata.",
      "owner_path": "src/twmn_portfolio/ctv_reporting.py",
      "path": "src/twmn_portfolio/ctv_reporting.py"
    },
    {
      "basis": "responsibility",
      "justification": "Own rebuildable read-only snapshots and fully verified read transactions, invalidate on external database/version changes, and scope cached connections to explicit worker/direct sessions so standalone reads release handles while warm worker reports retain one verified snapshot.",
      "owner_path": "src/twmn_portfolio/ctv_reporting_cache.py",
      "path": "src/twmn_portfolio/ctv_reporting_cache.py"
    },
    {
      "basis": "responsibility",
      "justification": "Normalize bounded shared history/statistics cohort filters, explicit Central date basis, pagination and known versus unknown classification selections without deriving financial values.",
      "owner_path": "src/twmn_portfolio/ctv_reporting_filters.py",
      "path": "src/twmn_portfolio/ctv_reporting_filters.py"
    },
    {
      "basis": "responsibility",
      "justification": "Expose retained reported versus signed economic import results, allocation/ROI/quantity snapshots, source-date precision and cost scope alongside the existing imported-summary reporting contract.",
      "owner_path": "src/twmn_portfolio/ctv_reporting_projection.py",
      "path": "src/twmn_portfolio/ctv_reporting_projection.py"
    },
    {
      "basis": "responsibility",
      "justification": "Select date-only grouping when either realized trades or imported account flows have source-date precision, preserving shared accounting totals without invented intraday ordering.",
      "owner_path": "src/twmn_portfolio/ctv_reporting_statistics.py",
      "path": "src/twmn_portfolio/ctv_reporting_statistics.py"
    },
    {
      "basis": "responsibility",
      "justification": "Select the dedicated source-summary detail when an imported historical summary is present, retaining the existing renderer and print behavior for actual trades.",
      "owner_path": "src/web/client-history-detail.ts",
      "path": "src/web/client-history-detail.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Coordinate filtered, deterministically paginated trade history, report errors and immutable trade selection through existing private read transport.",
      "owner_path": "src/web/client-history.ts",
      "path": "src/web/client-history.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Serialize filtered report rows and metadata as quoted CSV with units, unknown values, correction revisions and spreadsheet-formula neutralization; identify the export as a report rather than a complete backup.",
      "owner_path": "src/web/client-report-csv.ts",
      "path": "src/web/client-report-csv.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Build shared accessible history/statistics filters preserving exact account, period, SIM/LIVE, date basis, state and reporting distinctions in owner-entered selections.",
      "owner_path": "src/web/client-report-filters.ts",
      "path": "src/web/client-report-filters.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Own typed report filters, rows, version/cutoff metadata and response shapes, and serialize the same explicit filter and pagination values for history, statistics and CSV transport.",
      "owner_path": "src/web/client-report-types.ts",
      "path": "src/web/client-report-types.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Render shared report metadata, accessible tables, exact metric trace actions and explicit unknown values; project descriptive returned fields without financial recalculation.",
      "owner_path": "src/web/client-report-view.ts",
      "path": "src/web/client-report-view.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Render authoritative metric populations, versioned checklist/behavior/terminal breakdowns and separate equity/book plots with exact table alternatives and linked trade/event evidence.",
      "owner_path": "src/web/client-statistics-view.ts",
      "path": "src/web/client-statistics-view.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Render returned statistics with defined populations, missing/excluded counts, version/date metadata, evidence trace links and accessible table alternatives without calculating financial results in the browser.",
      "owner_path": "src/web/client-statistics.ts",
      "path": "src/web/client-statistics.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Expose strict private history/statistics/CSV read routes, translate validated query values to bounded worker requests, and stream deterministic pages while rejecting changed export cutoffs.",
      "owner_path": "src/web/server-reports.ts",
      "path": "src/web/server-reports.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Coordinate immutable private workbook previews, bounded paginated staging/receipts, exact reviewed-source and account-revision revalidation, and backup-first atomic repeat-safe application under the canonical write lock.",
      "owner_path": "src/twmn_portfolio/ctv_import.py",
      "path": "src/twmn_portfolio/ctv_import.py"
    },
    {
      "basis": "responsibility",
      "justification": "Decode bounded private workbook bytes, verify the supplied source hash and mapping version, and normalize explicit account/cutover/row-review assertions without executing Excel.",
      "owner_path": "src/twmn_portfolio/ctv_import_inputs.py",
      "path": "src/twmn_portfolio/ctv_import_inputs.py"
    },
    {
      "basis": "responsibility",
      "justification": "Reconstruct imported financial row meanings from retained raw source cells and verify source/provenance, period/date bounds, child receipts, unique applied batch, reviewed options, reconciliation totals and opening-bridge lineage inside the existing full integrity verifier.",
      "owner_path": "src/twmn_portfolio/ctv_import_integrity.py",
      "path": "src/twmn_portfolio/ctv_import_integrity.py"
    },
    {
      "basis": "responsibility",
      "justification": "Compare source-reported rows and signed transactions with the canonical account revision, flat cutoff and opening-balance bridge; expose unresolved, excluded, repeated and changed-overlap diagnostics before apply.",
      "owner_path": "src/twmn_portfolio/ctv_import_preview.py",
      "path": "src/twmn_portfolio/ctv_import_preview.py"
    },
    {
      "basis": "responsibility",
      "justification": "Project immutable historical summaries and explicit source dates into accounting/report values while retaining source-reported and signed economic meanings and unknown lifecycle components; supply legacy notes/source-link display fields only at the outward response boundary, preserving raw stored evidence and original command receipts.",
      "owner_path": "src/twmn_portfolio/ctv_import_projection.py",
      "path": "src/twmn_portfolio/ctv_import_projection.py"
    },
    {
      "basis": "responsibility",
      "justification": "Append source-bound historical trade summaries, signed account transactions and explicitly excluded non-CTV activity through existing journal tables, preserving source/row/version/batch receipts and creating exactly one reconciled opening period for new activity.",
      "owner_path": "src/twmn_portfolio/ctv_import_records.py",
      "path": "src/twmn_portfolio/ctv_import_records.py"
    },
    {
      "basis": "responsibility",
      "justification": "Recognize the accepted current M2L workbook version, required sheet/table/header identities and reference markers; return source-bound raw cells, row evidence and reconciliation totals without refreshing formulas.",
      "owner_path": "src/twmn_portfolio/ctv_workbook.py",
      "path": "src/twmn_portfolio/ctv_workbook.py"
    },
    {
      "basis": "responsibility",
      "justification": "Normalize historical trade and transaction rows conservatively, retaining original cells, reported totals, signed interpretations, date precision and actionable missing/broken-source diagnostics.",
      "owner_path": "src/twmn_portfolio/ctv_workbook_rows.py",
      "path": "src/twmn_portfolio/ctv_workbook_rows.py"
    },
    {
      "basis": "responsibility",
      "justification": "Read only bounded ZIP/XML members and relationships, shared strings, styles, cells and table definitions from supported workbook bytes; perform no spreadsheet execution, external-link refresh or source write.",
      "owner_path": "src/twmn_portfolio/ctv_workbook_xml.py",
      "path": "src/twmn_portfolio/ctv_workbook_xml.py"
    },
    {
      "basis": "responsibility",
      "justification": "Read and hash the selected bounded workbook locally and retain one immutable pending apply request, reviewed preview identity and command ID across uncertain retry.",
      "owner_path": "src/web/client-import-command.ts",
      "path": "src/web/client-import-command.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Display and print the same immutable imported historical summary, preserved notes/source fields and batch/journal evidence while making unknown actual legs, fills, setup and component outcomes explicit; imported summaries do not expose normal lifecycle editing.",
      "owner_path": "src/web/client-import-detail.ts",
      "path": "src/web/client-import-detail.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Coordinate Settings workbook selection/inspection, explicit source-row and cutoff assertions, immutable preview review, apply/exact-retry state, dirty-work navigation protection and paginated saved staging/receipts without browser financial arithmetic.",
      "owner_path": "src/web/client-import-panel.ts",
      "path": "src/web/client-import-panel.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Define the bounded current workbook upload/mapping constants and typed source-row, staging, preview and receipt contracts shared by private transport and import presentation.",
      "owner_path": "src/web/client-import-types.ts",
      "path": "src/web/client-import-types.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Render source receipts, collapsible raw source-total cells, explicit CTV provenance assertions, every row diagnostic, reconciliation previews and apply receipts as owner-visible text without computing money or fabricating missing history.",
      "owner_path": "src/web/client-import-view.ts",
      "path": "src/web/client-import-view.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Expose strictly validated private bounded import inspection/preview/list/apply routes under existing local security, translate exact revision and idempotency headers to the allowlisted worker and return its authoritative receipt/status.",
      "owner_path": "src/web/server-imports.ts",
      "path": "src/web/server-imports.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Owner-local visible tracker manager, repeated-launch handoff, responsive preparation/readiness state, browser opening only for its verified owned service, and explicit stop/recovery entry points; no broker or collector process ownership.",
      "owner_path": "src/twmn_portfolio/ctv_desktop.py",
      "path": "src/twmn_portfolio/ctv_desktop.py"
    },
    {
      "basis": "responsibility",
      "justification": "Kernel-held ownership and installation locks, atomically written bounded JSON control records, token-bound open/stop requests and orderly waiting for only this tracker manager; no PID-based termination or HTTP control endpoint.",
      "owner_path": "src/twmn_portfolio/ctv_desktop_control.py",
      "path": "src/twmn_portfolio/ctv_desktop_control.py"
    },
    {
      "basis": "responsibility",
      "justification": "Hidden child process creation with explicit runtime/database arguments, private inherited readiness and shutdown pipes, bounded startup reporting and occupied-port refusal; stop only the child object created by this supervisor.",
      "owner_path": "src/twmn_portfolio/ctv_desktop_service.py",
      "path": "src/twmn_portfolio/ctv_desktop_service.py"
    },
    {
      "basis": "responsibility",
      "justification": "Explicit Windows release preparation, reproducible application and wheel installation, installed-source verification, lock-protected publication of a selected release and shortcut, and failure preservation of the prior release and existing ledger.",
      "owner_path": "src/twmn_portfolio/ctv_install.py",
      "path": "src/twmn_portfolio/ctv_install.py"
    },
    {
      "basis": "responsibility",
      "justification": "Contained release paths, source/artifact/executable SHA-256 identities, supported runtime verification, active release selection and removal of process-environment injection; manifests identify installation content without replacing canonical data.",
      "owner_path": "src/twmn_portfolio/ctv_install_manifest.py",
      "path": "src/twmn_portfolio/ctv_install_manifest.py"
    },
    {
      "basis": "responsibility",
      "justification": "Typed Windows ctypes security API and portable access-policy evaluation enforce complete-tree ACL verification/restriction and reject redirected paths; small fixed PowerShell adapters resolve the known folder and create/read back the temporary shortcut with paths carried separately and bounded public failures. An explicit platform guard loads the same fixed Win32 libraries and preserves typed native ABI behavior while allowing portable strict type checking.",
      "owner_path": "src/twmn_portfolio/ctv_install_windows.py",
      "path": "src/twmn_portfolio/ctv_install_windows.py"
    },
    {
      "basis": "responsibility",
      "justification": "Read-only recorded or explicitly reviewed standalone snapshot comparison, bounded private recovery dispatch, exclusive creation of a new isolated SQLite restore target and logical/content reconciliation; explicitly reject active ledger/source/existing target replacement.",
      "owner_path": "src/twmn_portfolio/ctv_recovery.py",
      "path": "src/twmn_portfolio/ctv_recovery.py"
    },
    {
      "basis": "responsibility",
      "justification": "Strict generated snapshot IDs, source-bound persistent receipt discovery, private public-descriptor projection and safe immutable file/hash selection; distinguish recorded provenance from independently reviewed unrecorded exported copies.",
      "owner_path": "src/twmn_portfolio/ctv_recovery_catalog.py",
      "path": "src/twmn_portfolio/ctv_recovery_catalog.py"
    },
    {
      "basis": "responsibility",
      "justification": "Trusted native chooser and responsive recovery review with truthful later-save differences and source-provenance warning; explicit acknowledgement creates a generated isolated copy and receipt while preserving the active ledger.",
      "owner_path": "src/twmn_portfolio/ctv_recovery_desktop.py",
      "path": "src/twmn_portfolio/ctv_recovery_desktop.py"
    },
    {
      "basis": "responsibility",
      "justification": "Finite source-bound private-pipe export sessions, sequential bounded base64 chunks, file-identity/offset/final-digest validation, expiry and guaranteed handle release; never materialize an entire snapshot in the worker protocol.",
      "owner_path": "src/twmn_portfolio/ctv_recovery_exports.py",
      "path": "src/twmn_portfolio/ctv_recovery_exports.py"
    },
    {
      "basis": "responsibility",
      "justification": "Consistent read-only SQLite schema/table/row/image/completed-snapshot fingerprints, existing account financial projections and bounded missing/changed-row comparisons; inspection never initializes or migrates storage.",
      "owner_path": "src/twmn_portfolio/ctv_recovery_snapshot.py",
      "path": "src/twmn_portfolio/ctv_recovery_snapshot.py"
    },
    {
      "basis": "responsibility",
      "justification": "Shared typed backup catalog, comparison, generated download and transfer-state contracts used by private transport and presentation; type declarations do not provide runtime validation or their own financial authority.",
      "owner_path": "src/web/client-backup-types.ts",
      "path": "src/web/client-backup-types.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Accessible Settings backup status/choice/comparison presentation, retry-preserving Backup now, verified preparation followed by a persistent native download link and polling only on explicit click; truthful transfer state explains report versus backup and isolated recovery without exposing filesystem selectors through HTTP.",
      "owner_path": "src/web/client-backups.ts",
      "path": "src/web/client-backups.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Bounded inherited stdin shutdown control and removable listeners for the owned Node service, closing once on EOF/error/control input without introducing HTTP stop routes or arbitrary process selection.",
      "owner_path": "src/web/desktop-control.ts",
      "path": "src/web/desktop-control.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Private backup/catalog/comparison/export route registration, strict generated download metadata, non-consuming explicit HEAD probes, bounded sequential streaming with canonical base64 and digest validation, response-finish state, cancellation/expiry cleanup and worker handle release.",
      "owner_path": "src/web/server-backups.ts",
      "path": "src/web/server-backups.ts"
    },
    {
      "basis": "responsibility",
      "justification": "Own the frozen execution-specification values as data only (D-2 windows, gates, D-9/D-9a ladders, OC controls, stage gates, state vocabularies, journal kinds) versioned to the accepted spec hash; no behavior, no clock, no network, no broker path.",
      "owner_path": "src/twmn_portfolio/ctv_rule_table.py",
      "path": "src/twmn_portfolio/ctv_rule_table.py"
    },
    {
      "basis": "responsibility",
      "justification": "Own observation-frame validation and the two direction-relative encodings the spec names (D-2 watch state from the frame's exchange clock, the OBS-CENERGY warning enum) with fail-closed gap mapping; consume native states verbatim and recompute no study.",
      "owner_path": "src/twmn_portfolio/ctv_frame.py",
      "path": "src/twmn_portfolio/ctv_frame.py"
    },
    {
      "basis": "responsibility",
      "justification": "Own the one deterministic evaluation of the frozen rule table (M1-M10, G1-G4, D-6 exit precedence, D-7 proxies, D-9/D-9a pricing, OC-2/OC-3, stage routing and boundary blocking) as a pure function of frame, position and stage config with no network, wall clock, storage or broker dependency.",
      "owner_path": "src/twmn_portfolio/ctv_rule_engine.py",
      "path": "src/twmn_portfolio/ctv_rule_engine.py"
    },
    {
      "basis": "responsibility",
      "justification": "Own the durable append-only order journal with per-event fsync, sequence-verified replay and intent indexing over the frozen 6.4 event vocabulary; never open the canonical alert ledger or the tracker database.",
      "owner_path": "src/twmn_portfolio/ctv_order_journal.py",
      "path": "src/twmn_portfolio/ctv_order_journal.py"
    },
    {
      "basis": "responsibility",
      "justification": "Own the broker-write boundary: adapters refuse every write with ORDERS_DISABLED until an S08 activation record exists; the recording adapter is a deterministic offline fixture surface and no live transport exists in this delivery.",
      "owner_path": "src/twmn_portfolio/ctv_broker_adapter.py",
      "path": "src/twmn_portfolio/ctv_broker_adapter.py"
    },
    {
      "basis": "responsibility",
      "justification": "Own the single broker-writer role with persist-before-send durability, exclusive ownership, idempotent intents, ack/fill correlation, partial-fill obligations, reconcile-then-retry-same-request, the environment gate, and the fixed 6.4 financial mapping; never touch the alert ledger, tracker storage or any provider path.",
      "owner_path": "src/twmn_portfolio/ctv_order_owner.py",
      "path": "src/twmn_portfolio/ctv_order_owner.py"
    },
    {
      "basis": "responsibility",
      "justification": "Own the append-only trade-identity register binding one runtime trade_id to its checklist/decision id and tracker trade record with rebind refusal, replay-verified fsynced persistence, and no ledger, tracker-write or broker path.",
      "owner_path": "src/twmn_portfolio/ctv_trade_register.py",
      "path": "src/twmn_portfolio/ctv_trade_register.py"
    },
    {
      "basis": "responsibility",
      "justification": "Own the durable operations log for incidents, notifications and the owner's entry pause: fsynced sequence-verified JSONL, deduplicated open incidents with resolutions as separate records, fail-closed construction on corrupt or gapped logs, and no ledger or tracker-write path.",
      "owner_path": "src/twmn_portfolio/ctv_incidents.py",
      "path": "src/twmn_portfolio/ctv_incidents.py"
    },
    {
      "basis": "responsibility",
      "justification": "Own runtime status assembly from durable state only and the incident scan that triages uncertain responses, receipt incidents and trailing reconciliation requirements while resolving recovered incidents; no wall clock, network or broker dependency.",
      "owner_path": "src/twmn_portfolio/ctv_runtime.py",
      "path": "src/twmn_portfolio/ctv_runtime.py"
    },
    {
      "basis": "responsibility",
      "justification": "Own the only runtime write path to a tracker database: writes exclusively through the tracker's own storage API against an isolated copy keyed by deterministic ctv7-<digest> command ids so replays return stored receipts, refusing the canonical ledger, alerts-directory siblings, unregistered trades, unreconciled journals and open obligations.",
      "owner_path": "src/twmn_portfolio/ctv_tracker_bridge.py",
      "path": "src/twmn_portfolio/ctv_tracker_bridge.py"
    }
  ],
  "responsibility_boundary": {
    "does_not_own": "Corpus, original sources, indicators, live order transport and the live frame-producer loop (S08 activation), accounts, tracker storage, the canonical ledger, provider connections or any live runtime loop.",
    "owns": "Bounded source-cited CTV methodology consolidation, rule-to-source chain, retained-lesson coverage register, conflict and readiness registers, the frozen S04 implementation specification with its acceptance cases, the S05 TradeStation connection and input qualification, the S06 faithful-decision implementation and order-management evidence, the Revision 3 specification revision with its owner ruling record, and the S07 runtime integration evidence: the durable trade identity, operations log, runtime status with incident triage and recovery resolution, the isolated-copy tracker projection with its command-id idempotency and canonical-ledger guard, the spec 6.5 pause and recovery behavior, case traceability, independent review and artifact hashes, and verified continuation.",
    "path": "docs/ctv-mastery"
  },
  "schema_version": "1.0",
  "separation_of_concerns": {
    "after": "S07 delivers the integration: the append-only trade register, the fail-closed operations log, runtime status assembled from durable state with incident triage and recovery resolution, the owner's spec 6.5 pause guard with management continuing, partial-obligation reporting, ack-aware containment-expiry cancels, and the tracker bridge writing only through the tracker's own storage API against isolated copies with deterministic command ids, refusing the canonical ledger and alerts-directory siblings. Live execution stays disabled; the live frame-producer loop and live runtime loop remain S08.",
    "before": "S06 delivered the executable decision core and the one order owner, but nothing integrated them: no durable trade identity bound checklists to runtime trades, no operations log recorded incidents, notifications or an entry pause, no runtime status or incident triage existed, no pause could block new entries while management continued, partial-leg-fill obligations stayed invisible in reconcile receipts, and no runtime write path to a tracker database existed — recovery and visibility were design obligations only."
  }
}
```

Derived from `complexity-result.json`.
